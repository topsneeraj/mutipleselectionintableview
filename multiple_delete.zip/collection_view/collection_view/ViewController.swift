//
//  ViewController.swift
//  collection_view
//
//  Created by MACOS on 5/15/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var tbl: UITableView!
    
    var arr = ["1","2","3","4"];
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.leftBarButtonItem = self.editButtonItem;
        
        tbl.allowsMultipleSelectionDuringEditing = true;
        
        
       
        let item1 = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(self.test));
        
        
        self.toolbarItems = [item1];
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func test(sender:UIBarButtonItem) {
        
        
        let brr = self.tbl.indexPathsForSelectedRows;
        
        let indicestodelete = NSMutableIndexSet();
        
        for indexpth in brr! {
            
            indicestodelete.add(indexpth.row);
            
            
    
        }
        
    
       /* for index in indicestodelete {
            
            
            arr.remove(at: index);
            
            
        }
        */
        //arr.re
        
        
        tbl.beginUpdates();
        
        tbl.deleteRows(at: brr!, with: .left);
        
        tbl.endUpdates();
        
        
        
        
        
        
        /*
        
         NSArray *selectedCells = [self.tableeView indexPathsForSelectedRows];
         NSMutableIndexSet *indicesToDelete = [[NSMutableIndexSet alloc] init];
         for (NSIndexPath *indexPath in selectedCells) {
         [indicesToDelete addIndex:indexPath.row];
         }
         //arrayFromPlist is NSMutableArray
         [arrayFromPlist removeObjectsAtIndexes:indicesToDelete];
         [tableeView beginUpdates];
         [tableeView deleteRowsAtIndexPaths:selectedCells withRowAnimation:UITableViewRowAnimationAutomatic];
         [tableeView endUpdates];

        
        
        
        */
    }

    func handle(sender: UIBarButtonItem) {
        
        
        
        tbl.setEditing(false, animated: true);
        
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
        
        
        
    }
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        
        tbl .setEditing(true, animated: true);
        
        
        let item1 = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(self.handle));
        
        
        self.navigationItem.leftBarButtonItem = item1;
         //super.setEditing(true, animated: <#T##Bool#>)
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
        
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        cell.textLabel?.text = arr[indexPath.row];
        
        
        return cell;
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

